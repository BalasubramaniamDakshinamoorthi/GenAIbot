import io
import json
import logging
import os

import requests
import tqdm
from icecream import ic
from PyPDF2 import PdfReader

log_format = "[%(levelname)s] %(message)s"
logging.basicConfig(level=logging.INFO, format=log_format)
logger = logging.getLogger(__name__)


def info(s):
    logger.info(s)


ic.configureOutput(prefix="", outputFunction=info)


def download_and_parse_pdf(url):
    # Download the PDF file from the url
    info("downloading pdf")
    ic(url)
    response = requests.get(url)
    # Open the downloaded PDF file as a binary file
    pdf_file = io.BytesIO(response.content)
    # Create a PDF file reader object
    pdf_reader = PdfReader(pdf_file)
    # Initialize an empty string for the text
    text = ""
    info("parsing pdf")
    # Loop through each page in the PDF and extract the text
    for page_num in tqdm.tqdm(pdf_reader.pages):
        # page = pdf_reader.getPage(page_num)
        text += page_num.extract_text()
    # Return the extracted text
    return text


def parse_local(filename):
    pdf_reader = PdfReader(filename)
    # Initialize an empty string for the text
    text = ""
    info("parsing pdf")
    # Loop through each page in the PDF and extract the text
    for page_num in tqdm.tqdm(pdf_reader.pages):
        # page = pdf_reader.getPage(page_num)
        text += page_num.extract_text()
    # Return the extracted text
    return text


# TODO: update to pydantic in the long term future
def parse_source(source):
    parsed_result = {k: v for k, v in source.items()}
    title = parsed_result["title"]
    doc_format = parsed_result.pop("doc_format")
    url = parsed_result.pop("url")
    local = parsed_result.pop("local")
    info("parsing source:")
    ic(title)
    ic(doc_format)
    ic(url)
    ic(local)
    if doc_format == "pdf" and local != True:
        assert doc_format == url.split(".")[-1]
        parsed_result["text"] = download_and_parse_pdf(url)
        return parsed_result
    elif doc_format == "pdf" and local == True:
        parsed_result["text"] = parse_local(parsed_result["file"])
        return parsed_result
    else:
        logger.warn(f"unknown document format {doc_format}")
        return None
