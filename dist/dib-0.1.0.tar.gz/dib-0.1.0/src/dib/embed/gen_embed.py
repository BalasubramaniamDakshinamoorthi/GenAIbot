import json
import os

import openai
from dotenv import load_dotenv
from llama_index.core import (Document, Settings, StorageContext,
                              VectorStoreIndex)
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core.node_parser import (SemanticSplitterNodeParser,
                                          SentenceSplitter)
# from llama_index.embeddings.anyscale import AnyscaleEmbedding
from llama_index.embeddings.cohere import CohereEmbedding
from llama_index.vector_stores.qdrant import QdrantVectorStore
from qdrant_client import QdrantClient

load_dotenv()


def format_dict(published_list, data) -> list | None:

    data = [x for x in data if x["title"] not in published_list]
    if len(data) > 0:
        documents = []
        for doc in data:
            document = Document(
                text=doc["text"],
                metadata={
                    "title": doc["title"],
                    "authors": doc["author(s)"],
                    "publish_date": doc["Publish Date"],
                    "description": doc["description"],
                    "document_type": doc["doc_type"],
                },
            )
            documents.append(document)
        return documents
    else:
        return None


def gen_embeddings(published_list: list, data: list):

    documents = format_dict(published_list, data)

    if isinstance(documents, list):

        embed_model = CohereEmbedding(
            cohere_api_key=os.getenv("COHERE_API_PROD"),
            model_name="embed-english-v3.0",
            input_type="search_document",
        )
        Settings.embed_model = embed_model

        qdrant_client = QdrantClient(url=os.getenv("QDRANT_URL"), api_key=os.getenv("QDRANT_API"))

        vector_store = QdrantVectorStore(client=qdrant_client, collection_name="RAG_chunks")

        pipeline = IngestionPipeline(
            transformations=[
                SentenceSplitter(chunk_size=300, chunk_overlap=20),
                # SemanticSplitterNodeParser.from_defaults(buffer_size =1, breakpoint_percentile_threshold = 95, embed_model=embed_model),
                embed_model,
            ],
            vector_store=vector_store,
            disable_cache=True,
        )

        nodes = pipeline.run(documents=documents, show_progress=True)

        print(len(nodes))

    else:
        print("No new sources")
