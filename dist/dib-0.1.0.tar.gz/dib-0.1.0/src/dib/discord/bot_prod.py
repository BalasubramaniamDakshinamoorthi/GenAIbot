import os
# from groq import Groq
import discord
from dotenv import load_dotenv
from llama_index.postprocessor.cohere_rerank import CohereRerank
from llama_index.llms.groq import Groq
from llama_index.core import VectorStoreIndex, Settings
from llama_index.vector_stores.qdrant import QdrantVectorStore
from llama_index.embeddings.cohere import CohereEmbedding
from qdrant_client import QdrantClient
import os
from llama_index.core.chat_engine import CondenseQuestionChatEngine
from dotenv import load_dotenv
from llama_index.llms.anyscale import Anyscale
from llama_index.core.llms import ChatMessage, MessageRole
load_dotenv()


def set_client():
    
    qdrant_client = QdrantClient(url = os.getenv("QDRANT_URL"), api_key=os.getenv("QDRANT_API"))

    # llm = Anyscale(api_key = os.getenv("ANYSCALE_API_KEY"))
    llm = Groq(model="mixtral-8x7b-32768", api_key=os.getenv("GROQ_API"))

    embed_model = CohereEmbedding(cohere_api_key = os.getenv("COHERE_API_KEY"), model_name = "embed-english-v3.0", input_type="search_query")

    Settings.llm = llm
    Settings.embed_model = embed_model
    
    vector_store = QdrantVectorStore(client = qdrant_client, collection_name = "RAG_chunks")

    return vector_store, llm, embed_model


vector_store, llm, embed_model = set_client()

index = VectorStoreIndex.from_vector_store(vector_store = vector_store)

cohere_rerank = CohereRerank(api_key=os.getenv("COHERE_API_KEY"), top_n=2)


query_engine = index.as_query_engine(similarity_top_k=10, node_postprocessors=[cohere_rerank])

chat_engine = CondenseQuestionChatEngine.from_defaults(
    query_engine=query_engine,
    verbose=True,
    llm = llm,
    embed_model = embed_model
    )



# query_engine = index.as_chat_engine(
#     chat_mode="condense_question",
#     verbose=True,
#     similarity_top_k=10,
#     node_postprocessors=[cohere_rerank],
# )


# response = chat_engine.chat("Explain linear regression.")

# # import pdb;pdb.set_trace()

# print(response)


intents = discord.Intents.default()
intents.message_content = True


client = discord.Client(intents=intents)
# groq_client = Groq(api_key=os.getenv("GROQ_API"))


@client.event
async def on_ready():
    print(f"we have logged in as {client.user}")


@client.event
async def on_message(message):
    print(message.author)
    if message.author == client.user:
        return
    if message.content.startswith("$bot"):
        if type(message.channel) == discord.channel.TextChannel:
            async with message.channel.typing():
                proc_message = message.content.split("$bot ")[1]
                if len(proc_message)> 100:
                    message.channel = await message.create_thread(
                        name=proc_message[:90]
                    )
                else:
                    message.channel = await message.create_thread(
                            name=proc_message
                        )

                print(type(message.channel))
                # chat_completion = groq_client.chat.completions.create(
                #     messages=[{"role": "user", "content": proc_message}],
                #     model="mixtral-8x7b-32768",
                # )
                # response = chat_completion.choices[0].message.content
                chat_engine = CondenseQuestionChatEngine.from_defaults(
                    query_engine=query_engine,
                    verbose=True,
                    llm = llm,
                    embed_model = embed_model
                    )
                # chat_engine.reset()
                response = chat_engine.chat(proc_message)
                sources = response.sources
                final_response = response.response
                if len(final_response) > 1900:
                    final_response = final_response[:1900]
                print(final_response)
                print(sources)
                await message.channel.send(f"{final_response}")

        elif type(message.channel) == discord.threads.Thread:
            # print(message.channel.starter_message.content)
            messages = [
                message
                async for message in message.channel.history(
                    limit=25, oldest_first=True
                )
            ]
            
            full_mssg = []
            for idx, val in enumerate(messages):
                if str(val.author) != "LilJohn#0825":
                    if val.content.startswith("$bot "):
                        proc_message = val.content.split("$bot ")[1]
                        us_mssg = ChatMessage(role=MessageRole.USER, content=proc_message)
                        # new_dict = {"role": "user", "content": proc_message}
                        full_mssg.append(us_mssg)
                    else:
                        pass  # question whether we should add non $bot messages to llm mssg history
                else:
                    as_mssg = ChatMessage(role=MessageRole.ASSISTANT, content = val.content)
                    # new_dict = {"role": "assistant", "content": val.content}
                    full_mssg.append(as_mssg)
            # full_mssg[0] = {
            #     "role": "user",
            #     "content": message.channel.starter_message.content.split(
            #         "$bot "
            #     )[1],
            # }
            full_mssg[0] = ChatMessage(role=MessageRole.USER, content=message.channel.starter_message.content.split("$bot ")[1])
            
            print(full_mssg)

            # chat_completion = groq_client.chat.completions.create(
            #     messages=full_mssg,
            #     model="mixtral-8x7b-32768",
            # )
            # response = chat_completion.choices[0].message.content

            chat_engine = CondenseQuestionChatEngine.from_defaults(
                query_engine=query_engine,
                verbose=True,
                llm = llm,
                embed_model = embed_model,
                chat_history=full_mssg
                )
            # chat_engine.chat_history = full_mssg
            
            response = chat_engine.chat(proc_message).response
            if len(response) > 1900:
                response = response[:1900]
            print(response)
            await message.channel.send(f"{response}")


client.run(os.getenv("DISCORD_TOKEN"))


# GUILD = "TestBot"


# @client.event
# async def on_ready():
#     for guild in client.guilds:
#         if guild.name == GUILD:
#             break

#     print(
#         f"{client.user} is connected to the following guild:\n"
#         f"{guild.name}(id: {guild.id})"
#     )


# client.run(os.getenv("DISCORD_TOKEN"))
