# Discord Bot script

Herein lives LLM bot

Current Textbooks in Vector Database:
* The Elements of Statistical Learning by T.Hastie et al. (2008)
* Dive into Deep Learning by A. Zhang et al. (2023)
* Python Data Science Handbook by J. VanderPlas (2017)
* Introducing Python by B. Lubanovic (2020)
